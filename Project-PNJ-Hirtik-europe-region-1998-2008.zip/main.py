#########################################################################
#Title: PYTHON Project Scenario - Data Analysis
#Description: This program allows user to analyse the monthly vistors that visit the europe continent since 1998-2008
#Name: Hirtik Sundarum
#Group Name: Python Makkalz
#Class: PN2004J
#Date: 10/2/2021
#Version: 1.0
#########################################################################

#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################
#import pandas for data analysis
import pandas as pd
#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################
#import pie chart
import matplotlib.pyplot as pit

#########################################################################
#CLASS Branch - Data Analysis
#load excel data (CSV format) to dataframe
#########################################################################
class DataAnalysis:
  def __init__(self):

    #load excel data (CSV format) to dataframe - 'df'
    dataframe = pd.read_csv('MonthyVisitors.csv')
    #show specific country dataframe
    sortCountry(dataframe)
    
#########################################################################
#CLASS Branch: End of Code
#########################################################################

#########################################################################
#FUNCTION Branch - sortCountry
#parses data and displays sorted result(s)
#########################################################################
def sortCountry(df):

  #print number of rows in dataframe
  print("There are " + str(len(df)) + " data rows read. \n")

  #display dataframe (rows and columns)
  print("The following dataframe are read as follows: \n")
  print(df)

  #display a specific country(United Kingdom,Germany,France,Italy,Netherlands,Greece,Belguim & Luxembourg, Switzerland, Austria,Scandinavia,CIS & Eastern Europe)  in column #
  country_label = df.columns[17]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[18]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[19]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[20]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[21]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[22]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[23]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[24]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[25]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[26]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[27]
  print("\n\n" + country_label + "was selected.")

  #reading columns
  df.columns

  #display and sort the dataframe
  print(" The" + country_label + "was sorted in ascending order. \n")
  sorted_df =(df[['Year','month','United Kingdom','Germany','France','Italy','Netherlands','Greece','Belguim & Luxembourg','Switzerland','Austria','Scandinavia','CIS & Eastern Europe']][242:373])
  #printing data
  print(sorted_df)

  #converting the dtypes to objects
  sorted_df['United Kingdom'] = sorted_df['United Kingdom'].astype(int)
  sorted_df['Germany'] = sorted_df['Germany'].astype(int)
  sorted_df['France'] = sorted_df['France'].astype(int)
  sorted_df['Italy'] = sorted_df['Italy'].astype(int)
  sorted_df['Netherlands'] = sorted_df['Netherlands'].astype(int)
  sorted_df['Greece'] = sorted_df['Greece'].astype(int)
  sorted_df['Belguim & Luxembourg'] = sorted_df['Belguim & Luxembourg'].astype(int)
  sorted_df['Belguim & Luxembourg'] = sorted_df['Belguim & Luxembourg'].astype(int)
  sorted_df['Switzerland'] = sorted_df['Switzerland'].astype(int)
  sorted_df['Austria'] = sorted_df['Austria'].astype(int)
  sorted_df['Scandinavia'] = sorted_df['Scandinavia'].astype(int)
  sorted_df['CIS & Eastern Europe'] = sorted_df['CIS & Eastern Europe'].astype(int)
  #remove unwanted columns
  New =  sorted_df.drop(['Year','Month'], axis=1)
  #Add up the total number of visitors 
  total = New.sum()
  #Sort to descending number 
  SortedValue = total.sort_values(ascending=False)
  #reverting integers to objects 
  SortedValue = SortedValue.reset_index()
  #Adding columns label
  SortedValue.columns = ['Countries','Visitors']

  #sort the top 3 countries
  print("The top 3 countries are: ")
  print(SortedValue.head(n = 3))
  #pie chart
  activities = ['United Kingdom' , 'Germany' , 'France']
  slices = [ 7941631, 7443381, 3797093 ]
  colours = ['r' , 'g' , 'm']
  
  pit.pie(slices,
      labels=activities,
      startangle=90,
      shadow=True,
      explode=(0.2, 0, 0),
      autopct='%1.2f%%')

  pit.legend(loc="upper left")

  pit.show()

  return 
  
#########################################################################
#FUNCTION Branch: End of Code
#########################################################################

#########################################################################
#Main Branch
#########################################################################
if __name__ == '__main__':
  
  #Project Title
  print('######################################')
  print('# Data Analysis App - PYTHON Project #')
  print('######################################')

  #perform data analysis on specific excel (CSV) file
  DataAnalysis()

#########################################################################
#Main Branch: End of Code
#########################################################################