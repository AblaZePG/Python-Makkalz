#########################################################################
#Title: PYTHON Project Scenario - Data Analysis
#Description: This program allows user to analyse.......
#Name: Mark
#Group Name: Python Makkalz
#Class: PN2004J
#Date: 16 Feb 2021
#Version: <1.0>
#########################################################################
#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################
#import pandas for data analysis
import pandas as pd
#########################################################################
#import pie chart
import matplotlib.pyplot as pit
#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################

#########################################################################
#CLASS Branch - Data Analysis
#load excel data (CSV format) to dataframe
#########################################################################

#CLASS Branch - Data Analysis
#load excel data (CSV format) to dataframe
#####################################################################
class DataAnalysis:
  def __init__(self):

    #load excel data (CSV format) to dataframe - 'df'
    dataframe = pd.read_csv('MonthyVisitors.csv')
    #show specific country dataframe
    sortCountry(dataframe)
#########################################################################
#CLASS Branch: End of Code
#########################################################################

#########################################################################
#FUNCTION Branch - sortCountry
#parses data and displays sorted result(s)
#########################################################################
def sortCountry(df):

  #print number of rows in dataframe
  print("There are " + str(len(df)) + " data rows read. \n")

  #display dataframe (rows and columns)
  print("The following dataframe are read as follows: \n")
  print(df)

  #display a specific country (Brunei Darussalam, Indonesia, Malaysia, Philippines, Thailand, Vietnam, Myanmar) in column #2,3,4,5,6,7 and 8
  
  country_label = df.columns[2]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[3]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[4]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[5]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[6]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[7]
  print("\n\n" + country_label + "was selected.")
  country_label = df.columns[8]
  print("\n\n" + country_label + "was selected.")
 
  #display a sorted dataframe based on selected country
  print(" The" + country_label + "was sorted in ascending order. \n")
  sorted_df =df.sort_values(country_label,ascending=[0])
  print(sorted_df)

  #reading columns
  df.columns

  #sorting dataframe (rows and columns) 
  print("\nThe following dataframe are read as follows: \n")
  SortedDF = (df[[  
       'Year', 'Month', 'Brunei Darussalam', 'Indonesia', 'Malaysia', 'Philippines', 'Thailand', 'Vietnam', 'Myanmar' ]]
##################################################
 #Printing the data 
 print(SortedDF) 


 # This will convert dtypes from objects to int
 SortedDF[' Brunei Darussalam '] = SortedDF[' Brunei Darussalam '].astype(int)
 SortedDF[' Indonesia  '] = SortedDF[' Indonesia '].astype(int)
 SortedDF[' Malaysia  '] = SortedDF[' Malaysia '].astype(int)
 SortedDF[' Philippines  '] = SortedDF[' Philippines '].astype(int)
 SortedDF[' Thailand  '] = SortedDF[' Thailand '].astype(int)
 SortedDF[' Vietnam  '] = SortedDF[' Vietnam '].astype(int)
 SortedDF[' Myanmar  '] = SortedDF[' Myanmar '].astype(int)

 #Removing unwanted Columns
 New = SortedDF.drop(['Year', 'Month'], axis=1)

 #Add up the total amount of visitors
 total = New.sum()

 #Sorting on descending order
 Sortedvalue = total.sort_values(ascending=False)

 #Reverting back from Integers to Objects
 Sortedvalue = Sortedvalue.reset_index()

 #Adding in column labels
    Sortedvalue.columns = ['Countries', 'Visitors']

    #Sorting toward top 3 countries
    print(
        "The Top 3 countries of visitors travelling to Singapore in the span of 10 years are: " )

 print(Sortedvalue.head)
 #pie chart
 activities = []





  return
#########################################################################
#FUNCTION Branch: End of Code
#########################################################################

#########################################################################
#Main Branch
#########################################################################
if __name__ == '__main__':
  
  #Project Title
  print('######################################')
  print('# Data Analysis App - PYTHON Project #')
  print('######################################')

  #perform data analysis on specific excel (CSV) file
  DataAnalysis()

#########################################################################
#Main Branch: End of Code
#########################################################################